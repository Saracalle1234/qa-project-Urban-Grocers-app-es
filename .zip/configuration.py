URL_SERVICE = "https://cnt-1851cc48-ffdf-4116-bc1f-67a1c1ac7cc9.containerhub.tripleten-services.com"
CREATE_USER_PATH = "/api/v1/users"
KITS_PATH = "/api/v1/kits"
