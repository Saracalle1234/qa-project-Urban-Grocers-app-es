headers = {
    "Content-Type": "application/json"
}

user_body = {
    "first_name": "Sara",
    "phone": "573126305485",
    "address": "Calle 7 sur 41 63"
}

kit_body ={
    "name": "Nuevo kit"
}

